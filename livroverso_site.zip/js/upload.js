const db = firebase.firestore();
const storage = firebase.storage();
const auth = firebase.auth();
const form = document.getElementById("uploadForm");
const mensagem = document.getElementById("mensagem");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const titulo = document.getElementById("titulo").value;
  const autor = document.getElementById("autor").value;
  const arquivo = document.getElementById("arquivo").files[0];
  if (!auth.currentUser) {
    mensagem.textContent = "Você precisa estar logado para postar um eBook.";
    return;
  }
  const storageRef = storage.ref().child(`ebooks/${arquivo.name}`);
  try {
    await storageRef.put(arquivo);
    const url = await storageRef.getDownloadURL();
    await db.collection("ebooks").add({
      titulo,
      autor,
      url,
      userId: auth.currentUser.uid,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    mensagem.textContent = "eBook postado com sucesso!";
    form.reset();
  } catch (error) {
    console.error(error);
    mensagem.textContent = "Erro ao postar o eBook.";
  }
});
